import pandas as pd

def predict_scores(file_path):
    df = pd.read_csv(file_path)
    results = []
    for index, row in df.iterrows():
        name = row['Name']
        score = row['TotalScore']
        if score < 40:
            category = 'Low'
        elif score <= 65:
            category = 'Average'
        elif score <= 85:
            category = 'Good'
        else:
            category = 'Excellent'
        results.append({'name': name, 'score': score, 'category': category})
    return results
